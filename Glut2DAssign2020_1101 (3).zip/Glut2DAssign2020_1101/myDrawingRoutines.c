
#ifdef __APPLE_CC__
#include <GLUT/glut.h>
#else
#include <windows.h>
#include <gl\gl.h>
#include "glut.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "myDrawingRoutines.h"

void drawSun(int orbit_center_x, int orbit_center_y, int orbit_radius, 
 int sun_radius, float t)
 {
 	  int sun_x, sun_y;
 	  float theta; //the angle in radians
 	  
 	  //first figure out the center of the sun
 	  //on the orbit circle
 	  theta = 2*M_PI * t;//change t to radian angle
 	  sun_y = sin(theta) * orbit_radius + orbit_center_y;
 	  sun_x = cos(theta) * orbit_radius + orbit_center_x;
 	  
 	  glColor3f(1.0, 1.0, 0.0);
 	  drawCircle(sun_x, sun_y, sun_radius, 40); 
 }
 
 
void drawCircle(int center_x, int center_y, int radius, int nSides)
{
   float x, y;
   int angle, delta;
   float theta;
   
   delta =  360/nSides;

   glBegin(GL_POLYGON);

   for(angle = 0; angle < 360; angle += delta)
   {
      theta = angle * M_PI /180.0; //change to radians
      x = radius * cos(theta) + center_x;
      y = radius * sin(theta) + center_y;
      glVertex2f(x,y); 
   } 
   glEnd();  
}

void drawTree(int center_x, int bottom, int width, int height)
{
	int top, left, right;
	
	int trunk_dx = width/8;
	int trunk_top = bottom + height/4;
	
	left = center_x - width/2;
	right = center_x + width/2;
	top = bottom + height;
	
//	glColor3f(0.0, 0.0, 0.0);
//	glBegin(GL_LINE_LOOP);
//		glVertex2i(left, bottom);
//		glVertex2i(right, bottom);
//		glVertex2i(right, top);
//		glVertex2i(left, top);
//	glEnd();
	
	
	//draw the trunk
	glColor3f(0.7, 0.2, 0.1);
	glBegin(GL_QUADS);
		glVertex2i(center_x - trunk_dx , bottom);
		glVertex2i(center_x + trunk_dx, bottom);
		glVertex2i(center_x + trunk_dx, trunk_top);
		glVertex2i(center_x - trunk_dx, trunk_top);
	glEnd();
	
	//draw the foilage
	glColor3f(0.0, 0.6, 0.0);
	glBegin(GL_TRIANGLES);
		glVertex2i(left , trunk_top);
		glVertex2i(right , trunk_top);
		glVertex2i(center_x, top);
	glEnd();
	
	
	
	
}


 void drawDog(int left, int bottom, int width, int height)
 {
 	int right, top;
 	int head_w, head_h;
 	int body_w, body_h;
 	
 	right = left + width;
 	top = bottom + height;
 	head_w = width/4;
	head_h = height/4;
	body_h = height/5;
	body_w = width/5;
 	
	
	
	//draw the head of the dog
	glBegin(GL_QUADS);
	glColor3f(0.0, 0.0, 0.0);
 		glVertex2i(right, top);
 		glVertex2i(right-head_w, top);
 		glVertex2i(right-head_w, top-head_h);
 		glVertex2i(right, top-head_h);
 	
	 
	//draw the body of the dog
		glVertex2i(right-body_w, top-body_h);
		glVertex2i(left+body_w, top-body_h);
		glVertex2i(left+body_w, bottom+2*body_h);
		glVertex2i(right-body_w, bottom+2*body_h);
	glEnd();
	
	//draw the dog's legs and tail
	glBegin(GL_LINES);
		glVertex2i(left+body_w, bottom+2*body_h);//rear legs
		glVertex2i(left+body_w, bottom);
		
		glVertex2i(right-body_w, bottom+2*body_h);//front legs
		glVertex2i(right-body_w/2, bottom);
		glLineWidth(5.0);
		
		glVertex2i(left+body_w, top-body_h);//dog's tail
		glVertex2i(left, top);
	glEnd();	
	
	
 }
