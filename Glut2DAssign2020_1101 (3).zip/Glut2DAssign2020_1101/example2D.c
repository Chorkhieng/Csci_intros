/*
    CSCI  
    Kevin Lee
    
    This is a simple example to get you
    up and running with OpenGL and GLUT.

    This example can be used to do simple
    2 dimensional drawing.  Do your work in
    the function DrawScene()

 
   Assignment
   
 Draw a 2 dimensional scene using OpenGl -- make sure to use the following OpenGL functions
   
   glColor3f(GLfloat red, GLfloat green, GLfloat blue); 
   glVertex2i(GLint x, GLint y);
   
   glBegin(int mode) using GL_POINTS, GL_LINES, GL_TRIANGLES, GL_QUADS
   glEnd()
   
   
   I suggest you look at the example already done in DrawScene and figure out how it
   works first.  For more information on OpenGL the official web site is http://www.opengl.org/
   
  ------- OPTIONAL -------
  
  for more fun you might want to try playing with
      glPointSize(GLFloat size); //try numbers from 1.0 to 10.0
      glLineWidth(GLFloat width); //try numbers from 1.0 to 10.0
   make sure to call these function before a glBegin(), not between a glBegin() and glEnd()
   
   another fun thing to try is when you draw a triangle of quadrilateral change the color
   for each vertex, in other words use a call to glColor before the call to glVertex
   
   ------ END OF OPTIONAL ---------
   
 */
   
#ifdef __APPLE_CC__
#include <GLUT/glut.h>
#else
#include <windows.h>
#include <gl\gl.h>
#include "glut.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "myDrawingRoutines.h"

#define WINDOW_SIZE 500

/*function prototypes*/
void drawScene(void);
void display(void);
void myMouse(int button, int state, int x, int y);
void myMouseMove(int x, int y);
void myKeyboard(unsigned char key, int x, int y);
void mySpecialKeys(int key, int x, int y);

int getRand(int first, int last);
void init(void);
void drawGridLines(int small_spacing, int big_spacing);

void drawString(int x, int y, char theString[255]);
void drawEllipse(int center_x, int center_y, int x_radius, int y_radius, int nSides);



/* global variables -- generally a bad idea
these are used to illustrate using the mouse keep track of the last place clicked */
int gMouse_x = 200;
int gMouse_y = 100;
char gShowGrid = 0;

int height = 180;
int delta = 5;

int sun_x = 300;
int sun_y = 400;

int gArmState = 0;
char g_bAnimate = 0; //flag to decide if we animate
char g_showHiddenItem = 0;
float g_t = 0.0;
char g_showKevin = 0;

int ball_x = 180;
int ball_y = 80;
int inc = 5;

char g_Headhit = 0;

void drawCheckerSquares( float left,
float top, float rect_width, 
float rect_height, float kerf,
int rows, int cols);


/*
    This is the only function you should modify for this 
    assignment

*/
void drawScene(void)
{  
/* 
GL_POINTS, *GL_LINES, GL_LINE_STRIP, 
GL_LINE_LOOP, *GL_TRIANGLES, 
GL_TRIANGLE_STRIP, GL_TRIANGLE_FAN, 
GL_QUADS, GL_QUAD_STRIP, and *GL_POLYGON

*/


	glBegin(GL_QUADS);
	
		//draw the grass background
		glColor3f(0.0, 1.0, 0.0);
		glVertex2i(0, 0);
		glVertex2i(0, 250);
		glVertex2i(500, 250);
		glVertex2i(500, 0);
		
		//draw the sky
		glColor3f(0.0, 0.0, 1.0);
		glVertex2i(0, 500);
		glVertex2i(500, 500);
		
		glColor3f(1.0, 0.0, 0.0);
		glVertex2i(500, 250);
		glColor3f(1.0, 1.0, 0.0);
		glVertex2i(0, 250);
		
		//draw the driveway
		glColor3f(0.7, 0.9, 0.7);
		glVertex2i(100, 240);
		glVertex2i(150, 0);
		glVertex2i(500, 0);
		glVertex2i(130, 240);
	
	glEnd();
	
	//draw the house
	//start with the roof
	glBegin(GL_TRIANGLES);
		glColor3f(0.5, 1.0, 1.0);
		glVertex2i(100, 340);
		glVertex2i(20, 300);
		glVertex2i(180, 300);
		
	glEnd();
	
	//the base, window, and the door
	glBegin(GL_QUADS);
		//draw the base
		glColor3f(0.7, 0.4, 0.7);
		glVertex2i(20, 300);
		glVertex2i(20, 240);
		glVertex2i(180, 240);
		glVertex2i(180, 300);
		
		//draw the windows
		glColor3f(0.9, 0.9, 0.9);
		glVertex2i(35, 280);
		glVertex2i(35, 260);
		glVertex2i(60, 260);
		glVertex2i(60, 280);
		
		glVertex2i(65, 260);
		glVertex2i(80, 260);
		glVertex2i(80, 280);
		glVertex2i(65, 280);
		
		//draw the door
		glColor3f(1.0, 1.0, 1.0);//this is white
		glVertex2i(100, 280);
		glVertex2i(100, 240);
		glVertex2i(130, 240);
		glVertex2i(130, 280);
		
	glEnd();
		
	//draw the sun
	glColor3f(1.0, 1.0, 0.0);//yellow
	drawCircle(400, 420, 50, 20);
	
	//draw the tree
	drawTree(200, 240, 20, 100);
	
	// this code draws two squares, the start of the head
    glBegin(GL_QUADS);

		
	
		glColor3f(0.5, 0.5, 0.85);  //what ever follows will be in light blue 
        //a quad is specified by four vertices
        glVertex2i(220, 300); //this is the face
        glVertex2i(280, 300);
        glVertex2i(280, 360);
        glVertex2i(220, 360);
        
        glColor3f(0.0, 0.8, 0.0); //change the color, this is light green
        glVertex2i(240 - 8, 340 -8); //left eye
        glVertex2i(240 + 8, 340 -8);
        glVertex2i(240 + 8, 340 +8);
        glVertex2i(240 - 8, 340 +8);
        
        glColor3f(0.0, 0.8, 0.0); //change the color, this is light green
        glVertex2i(260 - 8, 340 -8); //right eye
        glVertex2i(260 + 8, 340 -8);
        glVertex2i(260 + 8, 340 +8);
        glVertex2i(260 - 8, 340 +8);
        
	glEnd();  //quit the quad mode, every glBegin() needs a glEnd()

	
	
    //go in to line mode to draw the body and legs
	glLineWidth(5.0); //setting the linewidth must be outside of a glBegin, glEnd block
   	glBegin(GL_LINES);
      glColor3f(0.0, 0.0, 0.0); //change the color, this is black
  
        //the main body
        glVertex2i(250, 300);  
        glVertex2i(250, 120);
       
        //the right arm
        glVertex2i(250, 250); //shoulder
        glVertex2i(180, 200); 
        
        //the left arm
        glVertex2i(250, 250); //shoulder
        glVertex2i(320, 200);
        
        //the left leg 
        glVertex2i(250, 120);  //hip
        glVertex2i(300, 80);
       
       //the right leg
       glVertex2i(200, 80);  //hip
        glVertex2i(250, 120);
              
   glEnd();  //quit the line mode, every glBegin() needs a glEnd()
  glLineWidth(1.0); 

   //use a triangle to draw the shoes
   glBegin(GL_TRIANGLES);
      glColor3f(1.0, 0.0, 0.0); //red for the shoe
        //the left shoe
        glVertex2i(300, 80);
        glVertex2i(320, 60);
        glVertex2i(280, 60);  
		
		//the right shoe
		glColor3f(1.0, 0.0, 0.0); //red for the shoe
        //the left shoe
        glVertex2i(200, 80);
        glVertex2i(220, 60);
        glVertex2i(180, 60);  	    
   glEnd();  //quit the triangle mode, every glBegin() must be matched with a call to glEnd()

	
	
	//draw the dog
	drawDog(350, 60, 140, 100);
    
    //draw a house
    glBegin(GL_LINES);
    
    
} /* drawScene */



void display(void)
{
   glClear(GL_COLOR_BUFFER_BIT); //this clears the scene
  
   drawScene();
   if (gShowGrid){
     drawGridLines(20, 100);
   }
  
/* this needs to be the last function call in display() */
 glutSwapBuffers(); 
     
}

//used to draw a coordinate grid so 
//we can see where we are
//remember the left, bottom is 0, 0
void drawGridLines(int small_spacing, int big_spacing)
{
    int i, j;
    
  glBegin(GL_LINES);
  glColor3f(1.0, 1.0, 0); //this should be yellow
   for(i = 0; i < WINDOW_SIZE; i += small_spacing){
          
        //horizontal line first
        glVertex2i(0, i);
        glVertex2i(WINDOW_SIZE,i);
        
        //vertical line next
        glVertex2i(i, 0);
        glVertex2i(i,WINDOW_SIZE);
   }
   
    
     glColor3f(1.0, 0.0, 0); //this should be red
    for(i = 0; i < WINDOW_SIZE; i += big_spacing){
        //horizontal line first
        glVertex2i(0, i);
        glVertex2i(WINDOW_SIZE,i);
        
        //vertical line next
        glVertex2i(i, 0);
        glVertex2i(i,WINDOW_SIZE);
   }
    glEnd();
}


int main(int argc, char *argv[])
{
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
 glutInitWindowSize(WINDOW_SIZE, WINDOW_SIZE);
 glutInitWindowPosition(100,40);
 glutCreateWindow("My First Glut/OpenGL Program");
 init();

 /* set up our call back functions */
 glutDisplayFunc(display);
 glutMouseFunc(myMouse);
 glutKeyboardFunc(myKeyboard);
 glutMotionFunc(myMouseMove);

 /* turn control over to glut */
 glutMainLoop();
 return 0;
}

void init(void)
{
 /*back ground color-set to white */
 glClearColor(1.0f ,1.0f ,1.0f ,0.0f);

 /*drawing color -set to black*/
 glColor3f(0.0f,0.0f,0.0f);

 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 gluOrtho2D(0.0f,(GLfloat)WINDOW_SIZE, 0.0f, (GLfloat) WINDOW_SIZE);
}

void myMouse(int button, int state, int x, int y)
{

    if(button == GLUT_LEFT_BUTTON)
    {
      if(state == GLUT_DOWN)
      {
          glutPostRedisplay();
          gMouse_x = x;
          gMouse_y = WINDOW_SIZE - y; /* GLUT puts the origin at the bottom left of the window, MS Windows treats the top right as the origin */
          //glutPostRedisplay(); /* tell glut to redraw the screen */
          printf("( %d, %d )\n", gMouse_x, gMouse_y);
       	  if (gMouse_x >= 220 && gMouse_x <= 280
			  && gMouse_y >= 300 && gMouse_y <= 360){
       	  	   g_Headhit = !g_Headhit;
       	  	   glutPostRedisplay();
		  }//if 
	   
	   }
    }
}

void myMouseMove(int x, int y)
{

}

void myTimer(int val)
{
      gArmState = (gArmState + 1) % 3; 
      
  //    printf("arm state %d\n", gArmState);
      
      g_t += 0.005;
      if(g_t >= 1.0){
      	g_t = 0.0;
	  }
//	  printf("g_t = %.2f\n", g_t);
	  
	  ball_y  = (ball_y + inc);
	  if (ball_y > 320){
	  	ball_y = 320;
	  	inc = -inc;
	  }
	  if (ball_y < 80){
	  	ball_y = 80;
	  	inc = -inc;
	  }
      
      glutPostRedisplay();
       if (g_bAnimate){
          glutTimerFunc(33, myTimer, 1);
       }
}

void myKeyboard(unsigned char key, int x, int y)
{
     if (key == 'g'){
       gShowGrid = !gShowGrid;
       glutPostRedisplay();
     }else if (key == 'h'){
           printf("Sorry, but there is no help for you, just figure it out\n");
     }else if (key == 'p'){
        printf("programmed by Kevin Lee\n");   
     }else if (key == 'a'){
          g_bAnimate = !g_bAnimate;
          if (g_bAnimate){
                 glutTimerFunc(100, myTimer, 1);
          }
     }else if(key == 'k'){
     	g_bAnimate = 0;
     	glutPostRedisplay(); 
	 }else if( key == 'w'){
         gArmState = (gArmState + 1) % 3; 
         glutPostRedisplay(); 
     }else if(key == 's'){
     	g_showHiddenItem = !g_showHiddenItem;
	 	glutPostRedisplay(); 
	 }else if (key == 'k'){
	 	g_showKevin = !g_showKevin;
	 	glutPostRedisplay(); 
	 }else{
	 	//must not have matched a key
	 	printf("%c not handled\n", key);
	 }
}

int getRand(int first, int last)
{
   static int firstTime = 1;
   int amountOfNumbers;
   if (firstTime == 1){
      //first time in this function, seed the random number generator
       firstTime = 0;
	   srand(time(NULL));
   }
   amountOfNumbers = last - first + 1;
   return(rand() % amountOfNumbers + first);
}



void drawLine(float x1, float y1,
    float x2, float y2)
{
    glBegin(GL_LINES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glEnd();
}

void drawCheckerSquares( float left,
float top, float rect_width, 
float rect_height, float kerf,
int rows, int cols)
{
     float right, y, x, bottom;
     int i;
     
     
     //first try drawing the horizontal lines
     right = left + cols * (rect_width + kerf);
     y = top;
     for(i = 0; i <= rows; ++ i)
     {
        drawLine(left, y, right, y);   
        y += rect_height + kerf;   
     } 
     
     //next try drawing the vertical lines
     x = left;
     bottom = top + rows * (rect_height + kerf);
     for(i = 0; i <= cols; ++ i)
     {
        drawLine(x, top, x, bottom);   
        x += rect_width + kerf;   
     } 
}



void drawString(int x, int y, char theString[255])
{
	int i, length;
	static int letters_to_draw = 0;
	length = strlen(theString);
	letters_to_draw = letters_to_draw + 1;
	if(letters_to_draw > length){
		letters_to_draw = 0;
    }
    if (!g_bAnimate){
      //trick into drawing the whole thing
	  letters_to_draw = length;	
    }
	glRasterPos2i(x, y);
	for(i = 0; i < letters_to_draw; i = i +1){
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24 ,theString[i]);
	}
}




void drawEllipse(int center_x, int center_y, int x_radius, int y_radius, int nSides)
{
   float x, y;
   int angle, delta;
   float theta;
   
   delta =  360/nSides;

   glBegin(GL_POLYGON);

   for(angle = 0; angle < 360; angle += delta)
   {
      theta = angle * M_PI /180.0; //change to radians
      x = x_radius * cos(theta) + center_x;
      y = y_radius * sin(theta) + center_y;
      glVertex2f(x,y); 
   } 
   glEnd();  
}




