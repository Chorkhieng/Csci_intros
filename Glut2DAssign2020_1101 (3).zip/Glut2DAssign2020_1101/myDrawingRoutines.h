/*
	prototypes for my brilliant drawing
	routines.
	
	(c) Kevin Lee


*/


 void drawSun(int center_x, int center_y, int orbit_radius, 
 int sun_radius, float t);
 
 void drawCircle(int center_x, int center_y, int radius, int nSides);
 
 void drawTree(int center_x, int bottom, int width, int heigth);
 
 void drawDog(int left, int bottom, int width, int height);
