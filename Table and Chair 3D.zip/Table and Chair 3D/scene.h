/*

        Header file for our 3D drawing code
        only need to declare the drawScene in here


*/

void drawScene(void);
void handleKey(char key);
