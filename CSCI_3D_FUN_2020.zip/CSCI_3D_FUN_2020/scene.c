/*
        CSCI Do your work in here.
       
        
        It is another chance to work with functions.
       
        Draw a 3D scene by creating functions to draw the scence
        call your functions from the drawScene function
        
      
 If it does not work at home you need to change these libraries (find them on your machine)

"C:/Program Files (x86)/Dev-Cpp/MinGW64/x86_64-w64-mingw32/lib32/libglu32.a"
"C:/Program Files (x86)/Dev-Cpp/MinGW64/x86_64-w64-mingw32/lib32/libglut32.a"
"C:/Program Files (x86)/Dev-Cpp/MinGW64/x86_64-w64-mingw32/lib32/libopengl32.a"


To change them look at project options under the project menu. Click on the parameters tab.
       
*/
#if __APPLE_CC__
#include <GLUT/glut.h>
#else
#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include "glut.h"
#endif



#include <math.h>
#include <stdio.h>
#include "scene.h"
#include <string.h>



extern float g_t;




//function prototypes for the local functions
void drawCone(float x, float y, float z, float radius, float height, int nSides, float startColor[3], float endColor[3]);

void drawBox(float left, float bottom, float front,
    float length, float height, float depth);

/*
   this function is called whenever OpenGL needs to redraw
   the screen
   
*/
void drawScene(void)
{
  float startColor[3] = { 0.5, 0.0, 0.0}, endColor[3] = {1.0, 1.0, 0.0};
//	drawCone(0,-1,0, 0.5, 1.0, 20, startColor, endColor);
 //   drawCone(0,1,0, 0.5, -1.0, 20, startColor, endColor);
	drawBox(0.0, 0.5, 0.25, 1.0, 0.5, 0.5);


}//drawScene

void drawCone(float x, float y, float z, float radius, float height, int nSides, float startColor[3], float endColor[3])
{
    int i, j, next;
    float angle;
    
    float circlePoints[100][3];
    float colors[100][3];
    
    //first calculate the points on a circle and the color for each point
    
    for(i = 0; i < nSides; ++i)
    {
       angle = 2* M_PI/nSides * i;
       circlePoints[i][0] = radius * sin(angle) + x;
       circlePoints[i][1] = y;
       circlePoints[i][2] = radius * cos(angle) + z;
       
       colors[i][0] = (endColor[0]- startColor[0])/ nSides * i + startColor[0];
       colors[i][1] = (endColor[1]- startColor[1])/ nSides * i + startColor[1];
       colors[i][2] = (endColor[2]- startColor[2])/ nSides * i + startColor[2];
    }
     //draw the cone
    glBegin(GL_TRIANGLES);
    for(i = 0; i < nSides; ++i)
    {
        next = (i + 1) % nSides;
        glColor3f(colors[i][0], colors[i][1], colors[i][2]);
        glVertex3f(circlePoints[next][0], circlePoints[next][1], circlePoints[next][2]);
        glVertex3f(x, y + height, z);
        
        glVertex3f(circlePoints[i][0], circlePoints[i][1], circlePoints[i][2]);
       // glVertex3f(x, y + height, z);
    }
    glEnd();
    
    //draw the circle
    glBegin(GL_POLYGON);
    for(i = 0; i < nSides; ++i)
    {
        glColor3f(startColor[0], startColor[1], startColor[2]);
        glVertex3f(circlePoints[i][0], circlePoints[i][1], circlePoints[i][2]);
    }
     glVertex3f(circlePoints[0][0], circlePoints[0][1], circlePoints[0][2]);
    glEnd();
}

/*
			x,X left
			y,Y bottom
			z Z front
			l L length
			h H height
			d D depth
*/
               
void handleKey(char key)
{
	printf("key = %c\n", key);

}

void drawBox(float left, float bottom, float front,
    float length, float height, float depth)
{
	float right = left + length;
	float top = bottom + height;
	float back = front - depth;
	//draw the front
	glBegin(GL_QUADS);
	
	
	//front
	glColor3f(1.0, 0.0, 0.0);
	glVertex3f(left, bottom, front);
	glVertex3f(right, bottom, front);
	glVertex3f(right, top, front);
	glVertex3f(left, top, front);
	
	//left
	glColor3f(0.0, 1.0, 0.0);
	glVertex3f(left, bottom, front);
	glVertex3f(left, top, front);
	glVertex3f(left, top, back);
	glVertex3f(left, bottom, back);
	
	
	glEnd();
}









 
