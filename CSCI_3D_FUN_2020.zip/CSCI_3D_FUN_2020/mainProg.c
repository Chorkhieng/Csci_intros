/* Rotating cube with color shading*/

/* Demonstration of use of homogeneous coordinate 
transformations and simple data structure for representing
cube from Chapter 4 */

/*Both normals and colors are assigned to the vertices */
/*Cube is centered at origin so (unnormalized) normals
are the same as the vertex values */

/* 
    Modified by Kevin Lee for CSCI 1111
     and CSCI 1101
*/



#if __APPLE_CC__
#include <GLUT/glut.h>
#else
#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#include "glut.h"
#endif






#include <math.h>
#include <stdio.h>
#include <assert.h>
#include "scene.h"
#include <ctype.h>

GLfloat planes[]= {-1.0, 0.0, 1.0, 0.0};
GLfloat planet[]= {0.0, -1.0,  0.0, 1.0};

	GLfloat vertices[][3] = {{-1.0,-1.0,-1.0},{1.0,-1.0,-1.0},
	{1.0,1.0,-1.0}, {-1.0,1.0,-1.0}, {-1.0,-1.0,1.0}, 
	{1.0,-1.0,1.0}, {1.0,1.0,1.0}, {-1.0,1.0,1.0}};

	GLfloat rot_vertices[][3] = {{-1.0,-1.0,-1.0},{1.0,-1.0,-1.0},
	{1.0,1.0,-1.0}, {-1.0,1.0,-1.0}, {-1.0,-1.0,1.0}, 
	{1.0,-1.0,1.0}, {1.0,1.0,1.0}, {-1.0,1.0,1.0}};

	GLfloat colors[][4] = {{0.0,0.0,0.0,0.2},{1.0,0.0,0.0,0.2},
	{1.0,1.0,0.0,0.2}, {0.0,1.0,0.0,0.2}, {0.0,0.0,1.0,0.2}, 
	{1.0,0.0,1.0,0.2}, {0.5,0.5,0.5,0.2}, {0.0,1.0,1.0,0.2}};
	
	int cubeFaceList[6][4] = {{0,3,2,1}, {2,3,7,6}, 
      {0,4,7,3}, {1,2,6,5}, {4,5,6,7}, {0,1,5,4}};
	
static GLfloat theta[] = {0.0,0.0,0.0};
static GLint axis = 2;	

// Rotation amounts
static GLfloat xRot = 0.0f;
static GLfloat yRot = 0.0f;

float g_t = 0.0;
	
	
void mouse(int btn, int state, int x, int y);
void myReshape(int w, int h);
void spinCube();
void key(unsigned char k, int x, int y);
void myTimer(int value);


char b_animate = 0;
char b_animate_time = 0;
char b_showHints = 0; //do we show the axis and point labels
char b_fullScreen = 0;
char b_wireFrame = 0;
char b_useOpenGLtransform = 1;
char b_texture = 1;
char b_lighting = 1;


int g_windowWidth;
int g_windowHeight;

int gi_projection_type = 1;
int per_angle = 45;

static int g_model = 0;

enum{
    ORTHO_3D,
    PERSPECTIVE
};


void drawString(char *pStr, double x, double y, double z);

void drawSphere(char wireFrame)
{
    GLUquadricObj *mySphere = gluNewQuadric();
    glPointSize(3.0);
    if (wireFrame)
       gluQuadricDrawStyle(mySphere, GLU_LINE);
    else
        gluQuadricDrawStyle(mySphere, GLU_FILL);
    
    gluSphere(mySphere, 1, 20,20);
    gluDeleteQuadric(mySphere);  
}


void rotateVertices(GLfloat source_vertices[][3], GLfloat dest_vertices[][3], int n)
{
  
  GLfloat m[16];
  GLfloat sum;
  int i, j, k;
    
  glPushMatrix();
  glLoadIdentity();

  	glRotatef(theta[0], 1.0, 0.0, 0.0);
	glRotatef(theta[1], 0.0, 1.0, 0.0);
	glRotatef(theta[2], 0.0, 0.0, 1.0);
    glGetFloatv(GL_MODELVIEW_MATRIX, m);
  glPopMatrix();
  
  for(k = 0; k < n; ++k)//step through all the points
  {
      //multiply the matrix times the the point
      
      for(i = 0; i < 3; ++i)
      {
            sum = 0;
            for (j = 0; j < 3; ++j)
            {
                 //M[i][j] * v[j]
                 sum += m[i + j * 4] * source_vertices[k][j];
            }
            //now for w
            sum += m[i + 3*4];
            dest_vertices[k][i] = sum;
      }
  }
}

void solidPolygon(int face, GLfloat vertices[][3])
{
int i, v;
   
  // glColor4fv(colors[face + 1]);
 	glBegin(GL_POLYGON);
 	for( i = 0; i < 4; ++i){
 	    v = cubeFaceList[face][i];
	//	glColor4fv(colors[v]);
		glVertex3fv(vertices[v]);
   }
	glEnd();
}

void polygon(int face, GLfloat vertices[][3])
{
   int i, v;
   
   glColor4fv(colors[face + 1]);
 	glBegin(GL_POLYGON);
 	for( i = 0; i < 4; ++i){
 	    v = cubeFaceList[face][i];
	//	glColor4fv(colors[v]);
		glVertex3fv(vertices[v]);
   }
	glEnd();
}

void drawCubeEdges(void)
{
   int i, j, v;
   
   glLineWidth(3.0);
   glColor3f(0.0, 0.0, 0.0);
   if (!b_useOpenGLtransform)
   {
        rotateVertices(vertices, rot_vertices, 8);
   }

   
   glLineWidth(3.0);
   glColor3f(0.0, 0.0, 0.0);
   if (!b_useOpenGLtransform)
   {
        rotateVertices(vertices, rot_vertices, 8);
   }
   
   for (j = 0; j < 6; ++j){
     glBegin(GL_LINE_LOOP);
 	for( i = 0; i < 4; ++i){
 	    v = cubeFaceList[j][i];
 	    if (!b_useOpenGLtransform)
 	    {
		    glVertex3fv(rot_vertices[v]);
        }else{
            glVertex3fv(vertices[v]);
        }
      }
     glEnd();
   }
}

void printModelViewMatrix()
{
     GLfloat m[16];
     int i,j;
     printf("\n\n\n");
     glGetFloatv(GL_MODELVIEW_MATRIX, m);
     for(i = 0; i < 4; ++i)
     {
          for(j = 0; j < 4; ++j)
          {
                printf("%8.3f ", m[i + 4 * j]);
          } 
          printf("\n");
     }
}



void labelVertices(GLfloat vertices[][3], int n)
{
  int i;
  
  assert(n < 10);
  glColor3f(0.0, 0.0, 0.0);
  for (i = 0; i < n; ++i){
      char name[]="0";
      name[0] = i + '0';
     drawString(name, vertices[i][0], vertices[i][1], vertices[i][2]);
   }
   
   //try to label the faces
   for (i = 0; i < 6; ++i){
      char name[]="0";
      name[0] = i + '0';
      int v0 =  cubeFaceList[i][0];
      int v2 =  cubeFaceList[i][2];
      
     drawString(name, (vertices[v0][0] + vertices[v2][0])/2.0, (vertices[v0][1] + vertices[v2][1])/2.0, (vertices[v0][2] + vertices[v2][2])/2.0);
   }
}



void drawArrow()
{
   GLfloat  triVerts[3][3] = {{0.0, 1.0, 0.0}, {0.75, 1.0, 0.0}, {0, 1.0, -1.0}};
   GLfloat quadVerts[4][3] = {{0.0, 1.0, 0.0}, {0.5, 1.0, 0.0}, {0.5, 1.0, 1.0}, {0.0, 1.0, 1.0} };
   
   int i;
   double thickness = 0.1;
   
   rotateVertices(triVerts, triVerts, 3);
   rotateVertices(quadVerts, quadVerts, 4);

   glBegin(GL_TRIANGLES);
      for(i = 0; i < 3; ++i)
           glVertex3fv(triVerts[i]);
     
      for(i = 0; i < 3; ++i)
           glVertex3f(triVerts[i][0], triVerts[i][1] - thickness, triVerts[i][2]);
   glEnd();

   
   glBegin(GL_QUADS);
      for(i = 0; i < 4; ++i)
          glVertex3fv(quadVerts[i]);
       
      for(i = 3; i >= 0; --i)
          glVertex3f(quadVerts[i][0], quadVerts[i][1] - thickness, quadVerts[i][2]);
          
   glEnd();

}
                          
void colorcube(void)
{
    int i; 
/* map vertices to faces */
    rotateVertices(vertices, rot_vertices, 8);
	for (i = 0; i < 6; ++i)
	{
	   if (!b_useOpenGLtransform)
 	    {
		    polygon(i,rot_vertices);
        }else{
            polygon(i,vertices);
        }
	}
	
	if(0 && b_showHints){
	  if (!b_useOpenGLtransform)
 	    {
            labelVertices(rot_vertices, 8);
        }else{
           labelVertices(vertices, 8);
        }
    }
}

void solidcube(void)
{
    int i; 
   
   rotateVertices(vertices, rot_vertices, 8);
/* map vertices to faces */
	for (i = 0; i < 6; ++i)
	{
	   if (!b_useOpenGLtransform)
 	    {
		    solidPolygon(i,rot_vertices);
        }else{
            solidPolygon(i,vertices);
        }
	}
	
	if(b_showHints){
	  if (!b_useOpenGLtransform)
 	    {
            labelVertices(rot_vertices, 8);
        }else{
           labelVertices(vertices, 8);
        }
    }
}



void drawAxes(void)
{
    glLineWidth(3.0);
    glBegin(GL_LINES);
        glColor3f(1.0, 0.0,0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(2.0, 0.0, 0.0); //x
        
        glColor3f(0.0, 1.0,0.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 2.0, 0.0);//y
        
        
       glColor3f(0.0, 0.0,1.0);
        glVertex3f(0.0, 0.0, 0.0);
        glVertex3f(0.0, 0.0, 2.0);//z
    glEnd();
}

void drawModel(char bShadow)
{
  if (b_wireFrame){
    if(g_model == 0)
         drawCubeEdges();
    else if (g_model == 1)
         drawArrow();
    else if (g_model == 2)
         glutWireTetrahedron();
     else if (g_model == 3)
         glutWireOctahedron();    
     else if (g_model == 4)
         glutWireDodecahedron(); 
     else if (g_model == 5)
         glutWireTeapot(1.0);
     else if (g_model == 6)
         glutWireIcosahedron();
     else if (g_model == 7)
         drawSphere(1);
    
  }else{
     if(g_model == 0){
         if (bShadow)
            solidcube();
         else
            colorcube();
     }else if (g_model == 1)
         drawArrow();
     else if (g_model == 2)
         glutSolidTetrahedron();
     else if (g_model == 3)
         glutSolidOctahedron();    
     else if (g_model == 4)
         glutSolidDodecahedron(); 
     else if (g_model == 5)
         glutSolidTeapot(1.0);
     else if (g_model == 6)
         glutSolidIcosahedron();
     else if (g_model == 7)
         drawSphere(0);
  }
}

void display(void)
{
/* display callback, clear frame buffer and z buffer,
   rotate cube and draw, swap buffers */

 glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
 // glMatrixMode(GL_PROJECTION);

//	 gluLookAt(7.0 * sin(xRot*M_PI/180.0),1,7.0 * cos(xRot*M_PI/180.0), 0, 0, 0, 0,1,0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
 
   	if ( b_useOpenGLtransform){
	 	glRotatef(theta[0], 1.0, 0.0, 0.0);
	 	glRotatef(theta[1], 0.0, 1.0, 0.0);
	 	glRotatef(theta[2], 0.0, 0.0, 1.0);
	}
	
	glColor3f(0.0, 0.0, 0.0);
  drawScene();
   //drawModel(g_model);
   if(b_showHints){
     drawAxes();
     glLineWidth(1.0);
       colorcube();
       glColor3f(0.8, 0.9, 0.7);
      // drawCubeEdges();
    }
	
   
   glutSwapBuffers();
}

void setAlphaChannel(double alpha)
{
   int i;
   for(i = 0; i < 8; ++i){
      colors[i][3] = alpha;
   }
}

void spinCube()
{
/* Idle callback, spin cube 2 degrees about selected axis */

	theta[axis] += 2.0;
	if( theta[axis] > 360.0 ) theta[axis] -= 360.0;
	/* display(); */
	glutPostRedisplay();
}

void mouse(int btn, int state, int x, int y)
{

/* mouse callback, selects an axis about which to rotate */
  //   theta[0] = theta[1] = theta[2] = 0.0;
	if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN){ axis = 0;}
	if(btn==GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) axis = 1;
	if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) axis = 2;
}

void myReshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    double aspect;
    
     g_windowWidth = w;
     g_windowHeight = h;

		
		aspect = (GLdouble)h/(GLdouble)w;
	
   if(gi_projection_type == ORTHO_3D){
      if (w < h){
		aspect = (GLdouble)h/(GLdouble)w;
	    glOrtho(-3.0, 3.0, -3.0 * aspect,
            3.0 * aspect, -10.0, 10.0);  
      }else{
		aspect = (GLdouble)w/(GLdouble)h;
		glOrtho(-3.0 * aspect, 3.0  * aspect, -3.0,
            3.0 , -10.0, 10.0);  
      }  
   }else{
       if (w < h)
		aspect = (GLdouble)h/(GLdouble)w;
	   else
		aspect = (GLdouble)w/(GLdouble)h;
         gluPerspective(per_angle, aspect, 2, 10);
    }
    
   gluLookAt(7.0 * sin(xRot*M_PI/180.0),1,7.0 * cos(xRot*M_PI/180.0), 0, 0, 0, 0,1,0);
    glMatrixMode(GL_MODELVIEW);
}

void toggleFullScreen()
{
     static int old_height, old_width, old_x, old_y;
     b_fullScreen = !b_fullScreen;
	    if (b_fullScreen){
           old_height = glutGet(GLUT_WINDOW_HEIGHT);               
           old_width = glutGet(GLUT_WINDOW_WIDTH);   
           old_x = glutGet(GLUT_WINDOW_X);
           old_y = glutGet(GLUT_WINDOW_Y);            
                          
          glutFullScreen();
        }else{
            glutReshapeWindow(old_width,old_height);
            glutPositionWindow(old_x,old_y);
        }   
}
/*
void key(unsigned char k, int x, int y)
{
    k = tolower(k);
	if(k == 'a'){
       b_animate = !b_animate;
       if (b_animate){
           glutTimerFunc(33, myTimer, 1);
       }
    }else if (k == 'h'){
        b_showHints = !b_showHints;
        glutPostRedisplay();
    }else if(k == 'f'){
	     toggleFullScreen();
    }else if (k == 'o'){
             gi_projection_type = ORTHO_3D;
             myReshape(g_windowWidth, g_windowHeight);
             glutPostRedisplay();
    }else if (k == 'p'){
            gi_projection_type = PERSPECTIVE;
             myReshape(g_windowWidth, g_windowHeight);
             glutPostRedisplay();
    }else if (k >= '0' && k <= '9'){
        double alpha = (k - '0') * 0.1;
        if (alpha == 0)
           alpha = 1.0;
        setAlphaChannel(alpha);   
        glutPostRedisplay();
    }else if (k == '+'){
          per_angle += 2;
          myReshape(g_windowWidth, g_windowHeight);
          glutPostRedisplay();
     }else if (k == '-'){
          per_angle -= 2;
          myReshape(g_windowWidth, g_windowHeight);
          glutPostRedisplay();
     }else if (k == 'm'){
           printModelViewMatrix();
     }else if (k == 'w'){
          b_wireFrame = !b_wireFrame;
          glutPostRedisplay();
     }else if (k == 'q'){
          b_useOpenGLtransform = !b_useOpenGLtransform;
          glutPostRedisplay();
     }else if (k == 'n'){
          g_model = (g_model + 1)%8;
          glutPostRedisplay();
     }else if (k == 't'){
          b_texture = !b_texture;
          glutPostRedisplay();
     }else if (k == 'l'){
          b_lighting = !b_lighting;
          glutPostRedisplay();
     }
}
*/


void key(unsigned char k, int x, int y)
{
  //  k = tolower(k);
    
	if(k == 'a'){
          b_animate = !b_animate;
          if (b_animate){
               glutTimerFunc(33, myTimer, 1); 
          }
    }else if (k == '?'){
        b_showHints = !b_showHints;
        glutPostRedisplay();
    }else if(k == 'f' || k == 'F'){
	     toggleFullScreen();
    }else if (k == 'o'){
             gi_projection_type = ORTHO_3D;
             myReshape(g_windowWidth, g_windowHeight);
             glutPostRedisplay();
    }else if (k == 'p'){
            gi_projection_type = PERSPECTIVE;
             myReshape(g_windowWidth, g_windowHeight);
             glutPostRedisplay();
    }else if (k >= '0' && k <= '9'){
        double alpha = (k - '0') * 0.1;
        if (alpha == 0)
           alpha = 1.0;
        setAlphaChannel(alpha);   
        glutPostRedisplay();
    }else if (k == '+'){
          per_angle += 2;
          myReshape(g_windowWidth, g_windowHeight);
          glutPostRedisplay();
     }else if (k == '-'){
          per_angle -= 2;
          myReshape(g_windowWidth, g_windowHeight);
          glutPostRedisplay();
     }else if (k == 'm'){
           printModelViewMatrix();
     }else if (k == 'w'){
          b_wireFrame = !b_wireFrame;
          glutPostRedisplay();
     }else if (k == 'q'){
          b_useOpenGLtransform = !b_useOpenGLtransform;
          glutPostRedisplay();
     }else if (k == 'n'){
          g_model = (g_model + 1)%8;
          glutPostRedisplay();
     }else if (k == 't'){
          b_animate_time = !b_animate_time ;
          if (b_animate_time){
               glutTimerFunc(33, myTimer, 1); 
          }
          glutPostRedisplay();
     }else{
        // printf("not a valid key\n"); 
		handleKey(k); 
     }
           
}



void drawString(char *pStr, double x, double y, double z)
{
    int i, len;
    len = strlen(pStr);
    glRasterPos3f(x, y, z);
  
    for(i = 0; i < len; ++i)
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, pStr[i]);

}

void myTimer(int value)
{
	
	static float dt = 0.02;
 if (b_animate)   
 	spinCube();
  glutPostRedisplay();
  
    g_t = g_t + dt;
    if (g_t > 1.0){
    	g_t = 1.0;
    	dt = -0.02;
	}else if (g_t < -1){
		g_t = -1.0;
		dt = 0.02;
		
	}
    if (b_animate || b_animate_time)
       glutTimerFunc(33, myTimer, 1);
}

///////////////////////////////////////////////////////////////////////////////
// Process arrow keys
void SpecialKeys(int key, int x, int y)
{
	if(key == GLUT_KEY_LEFT )
		xRot-= 5.0f;

	if(key == GLUT_KEY_RIGHT )
		xRot += 5.0f;

	if(key == GLUT_KEY_UP)
		yRot += 5.0f;

	if(key == GLUT_KEY_DOWN)
		yRot -= 5.0f;
 

	if(xRot > 356.0f)
		xRot = 0.0f;

	if(xRot < -1.0f)
		xRot = 355.0f;

	if(yRot > 356.0f)
		yRot = 0.0f;

	if(yRot < -1.0f)
		yRot = 355.0f;

	// Refresh the Window
	glutPostRedisplay();
}



int main(int argc, char **argv)
{
   GLubyte image[64][64][3];
   int i, j, r, c;
   for(i=0;i<64;i++)
   {
     for(j=0;j<64;j++)
     {
       c = ((((i&0x8)==0)^((j&0x8))==0))*255;
       image[i][j][0]= (GLubyte) c;
       image[i][j][1]= (GLubyte) c;
       image[i][j][2]= (GLubyte) c;
     }
   }
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutCreateWindow("colorcube");
    
 //   initLighting();

/* need both double buffering and z buffer */

    glutReshapeFunc(myReshape);
    glutDisplayFunc(display);
//   glutIdleFunc(spinCube);
    glutMouseFunc(mouse);
    glEnable(GL_DEPTH_TEST);
    glutSpecialFunc(SpecialKeys);
    glutKeyboardFunc(key);

   glEnable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	
	glClearColor(1.0,1.0,1.0,1.0);

    glutMainLoop();
    
    return 0;
}
